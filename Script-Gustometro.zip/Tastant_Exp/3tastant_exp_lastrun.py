﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2022.1.1),
    on dicembre 09, 2022, at 16:32
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard

import serial
import struct
port = serial.Serial("COM4")





# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2022.1.1'
expName = '3tastant_exp'  # from the Builder filename that created this script
expInfo = {'participant': 'n', 'session': '01', 'num_trial': '1', 'num_stim': '2', 'cleaning': '2', 'p_omega': '368.26', 'p_stimulus_pulse_duration': '100', 'p_motor_pulse_width': '20'}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + 'data' + os.sep + '%s_%s' % (expInfo['participant'], expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\alber\\Desktop\\Tastant_Exp\\3tastant_exp_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.WARNING)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1536, 864], fullscr=False, screen=0, 
    winType='pyglet', allowGUI=True, allowStencil=False,
    monitor='testMonitor', color='black', colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='norm')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# Setup ioHub
ioConfig = {}

# Setup iohub keyboard
ioConfig['Keyboard'] = dict(use_keymap='psychopy')

ioSession = '1'
if 'session' in expInfo:
    ioSession = str(expInfo['session'])
ioServer = io.launchHubServer(window=win, **ioConfig)
eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='iohub')

# Initialize components for Routine "open_serial"
open_serialClock = core.Clock()

# Initialize components for Routine "Loading_syringe"
Loading_syringeClock = core.Clock()
key_select = keyboard.Keyboard()
text_4 = visual.TextStim(win=win, name='text_4',
    text='digit:\n1 to charge salt\n2 to charge sweet\n3 to charge neutral\nq to discharge salt\nw to discharge sweet\ne to discharge neutral\nspace to start experiment',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "charcedordischarced"
charcedordischarcedClock = core.Clock()
PressToFinish = visual.TextStim(win=win, name='PressToFinish',
    text="press 'space' to finish ",
    font='Open Sans',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
Exitkey = keyboard.Keyboard()

# Initialize components for Routine "motorEnd"
motorEndClock = core.Clock()
polygon_2 = visual.ShapeStim(
    win=win, name='polygon_2',
    size=(0.5, 0.5), vertices='circle',
    ori=0.0, pos=(0, 0), anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-1.0, interpolate=True)

# Initialize components for Routine "Start"
StartClock = core.Clock()
#importo la libreria time per i ritardi che dovrò utilizzare per poter leggere 
#distintamente i valori riportati da Arduino attraverso la seriale
import time
#Invio ad Arduino la parola chiave per entrare nel blocco condizionale dello 
#sketch per poter settare i parametri dell'esperimento.
port.write(b"start")
port.flush()
time.sleep(1.5)
#I valori mandati ad Arduino con un ritardo di 1.5 ms tra uno e l'altro per 
#permettere un'acquisizione corretta.
#(valore del ritardo determinato attraverso varie prove)
port.write(expInfo['p_omega'].encode('utf-8'))
port.flush()
time.sleep(1.5)
port.write(expInfo['p_stimulus_pulse_duration'].encode('utf-8'))
port.flush()
time.sleep(1.5)
port.write(expInfo['p_motor_pulse_width'].encode('utf-8'))
port.flush()
#Arduino invierà a py "<END loading: omega=" ", pulse_duration=" ">". Py lo stamperà.
data3 = port.readline()
data3 = str(data3.decode("utf"))
print(data3)

# Initialize components for Routine "Instruct"
InstructClock = core.Clock()
instrText = visual.TextStim(win=win, name='instrText',
    text='\nIgnore the word itself; press:\nRIGHT for SWEET stimulus (BLUE)\nLEFT for SALTY stimulus (RED)\n(Esc will quit)\n\nPress any key to continue',
    font='Arial',
    pos=[0, 0], height=0.1, wrapWidth=None, ori=0, 
    color=[1, 1, 1], colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
ready = keyboard.Keyboard()

# Initialize components for Routine "countdown"
countdownClock = core.Clock()
time3 = visual.TextStim(win=win, name='time3',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "trial"
trialClock = core.Clock()
image = visual.ImageStim(
    win=win,
    name='image', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)

# Initialize components for Routine "jitter"
jitterClock = core.Clock()
fix_rand = visual.TextStim(win=win, name='fix_rand',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "risposta"
rispostaClock = core.Clock()
Risposta = keyboard.Keyboard()
LeftorRight = visual.TextStim(win=win, name='LeftorRight',
    text='\n<--left for sweet\n-->right for salty',
    font='Open Sans',
    pos=(0, 0), height=0.2, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "neutral"
neutralClock = core.Clock()
stim_neutral_word = visual.TextStim(win=win, name='stim_neutral_word',
    text='',
    font='Arial',
    pos=[0, 0], height=0.2, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "thanks"
thanksClock = core.Clock()
thanksText = visual.TextStim(win=win, name='thanksText',
    text='This is the end of the experiment.\n\nThanks!',
    font='arial',
    pos=[0, 0], height=0.2, wrapWidth=None, ori=0, 
    color=[1, 1, 1], colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "open_serial"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
open_serialComponents = []
for thisComponent in open_serialComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
open_serialClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "open_serial"-------
while continueRoutine:
    # get current time
    t = open_serialClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=open_serialClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in open_serialComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "open_serial"-------
for thisComponent in open_serialComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "open_serial" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
cicloricarica = data.TrialHandler(nReps=10.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('loopTemplate1.xlsx'),
    seed=None, name='cicloricarica')
thisExp.addLoop(cicloricarica)  # add the loop to the experiment
thisCicloricarica = cicloricarica.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisCicloricarica.rgb)
if thisCicloricarica != None:
    for paramName in thisCicloricarica:
        exec('{} = thisCicloricarica[paramName]'.format(paramName))

for thisCicloricarica in cicloricarica:
    currentLoop = cicloricarica
    # abbreviate parameter names if possible (e.g. rgb = thisCicloricarica.rgb)
    if thisCicloricarica != None:
        for paramName in thisCicloricarica:
            exec('{} = thisCicloricarica[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "Loading_syringe"-------
    continueRoutine = True
    # update component parameters for each repeat
    key_select.keys = []
    key_select.rt = []
    _key_select_allKeys = []
    # keep track of which components have finished
    Loading_syringeComponents = [key_select, text_4]
    for thisComponent in Loading_syringeComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Loading_syringeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Loading_syringe"-------
    while continueRoutine:
        # get current time
        t = Loading_syringeClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Loading_syringeClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *key_select* updates
        waitOnFlip = False
        if key_select.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_select.frameNStart = frameN  # exact frame index
            key_select.tStart = t  # local t and not account for scr refresh
            key_select.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_select, 'tStartRefresh')  # time at next scr refresh
            key_select.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_select.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_select.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_select.status == STARTED and not waitOnFlip:
            theseKeys = key_select.getKeys(keyList=['1','2','3','q','w','e','space'], waitRelease=False)
            _key_select_allKeys.extend(theseKeys)
            if len(_key_select_allKeys):
                key_select.keys = _key_select_allKeys[-1].name  # just the last key pressed
                key_select.rt = _key_select_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *text_4* updates
        if text_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_4.frameNStart = frameN  # exact frame index
            text_4.tStart = t  # local t and not account for scr refresh
            text_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_4, 'tStartRefresh')  # time at next scr refresh
            text_4.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Loading_syringeComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Loading_syringe"-------
    for thisComponent in Loading_syringeComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if key_select.keys in ['', [], None]:  # No response was made
        key_select.keys = None
    cicloricarica.addData('key_select.keys',key_select.keys)
    if key_select.keys != None:  # we had a response
        cicloricarica.addData('key_select.rt', key_select.rt)
    # the Routine "Loading_syringe" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "charcedordischarced"-------
    continueRoutine = True
    # update component parameters for each repeat
    Exitkey.keys = []
    Exitkey.rt = []
    _Exitkey_allKeys = []
    #Attraverso la digitazione nella routine precedente è possibile selezionare
    #i motori in modalità continua per poter riempire o svuotare le siringhe.
    
    
    #key_select.keys è la variabile che assume il valore o la lettera digitata da 
    #tastiera in key_select.
    
    if key_select.keys=='1':
        #il motore 1 è associato allo stimolo salato
        a="salato";
        port.write(a.encode('utf-8'))
        port.flush()
    elif key_select.keys=='2':
        #il motore 2 è associato allo stimolo dolce
        a="dolce";
        port.write(a.encode('utf-8'))
        port.flush()
    elif key_select.keys=='3': 
        #il motore 0 è associato allo stimolo salato
        a="neutro";
        port.write(a.encode('utf-8'))
        port.flush()
    elif key_select.keys=='q':
        #il motore 2 è associato allo stimolo dolce
        a="salt";
        port.write(a.encode('utf-8'))
        port.flush()
    elif key_select.keys=='w':
        #il motore 2 è associato allo stimolo dolce
        a="sweet";
        port.write(a.encode('utf-8'))
        port.flush()
    elif key_select.keys=='e': 
        #il motore 0 è associato allo stimolo salato
        a="natural";
        port.write(a.encode('utf-8'))
        port.flush()
    
    
    # keep track of which components have finished
    charcedordischarcedComponents = [PressToFinish, Exitkey]
    for thisComponent in charcedordischarcedComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    charcedordischarcedClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "charcedordischarced"-------
    while continueRoutine:
        # get current time
        t = charcedordischarcedClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=charcedordischarcedClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *PressToFinish* updates
        if PressToFinish.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            PressToFinish.frameNStart = frameN  # exact frame index
            PressToFinish.tStart = t  # local t and not account for scr refresh
            PressToFinish.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PressToFinish, 'tStartRefresh')  # time at next scr refresh
            PressToFinish.setAutoDraw(True)
        
        # *Exitkey* updates
        if Exitkey.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Exitkey.frameNStart = frameN  # exact frame index
            Exitkey.tStart = t  # local t and not account for scr refresh
            Exitkey.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Exitkey, 'tStartRefresh')  # time at next scr refresh
            Exitkey.status = STARTED
            # keyboard checking is just starting
            Exitkey.clock.reset()  # now t=0
        if Exitkey.status == STARTED:
            theseKeys = Exitkey.getKeys(keyList=['space'], waitRelease=False)
            _Exitkey_allKeys.extend(theseKeys)
            if len(_Exitkey_allKeys):
                Exitkey.keys = _Exitkey_allKeys[-1].name  # just the last key pressed
                Exitkey.rt = _Exitkey_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in charcedordischarcedComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "charcedordischarced"-------
    for thisComponent in charcedordischarcedComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if Exitkey.keys in ['', [], None]:  # No response was made
        Exitkey.keys = None
    cicloricarica.addData('Exitkey.keys',Exitkey.keys)
    if Exitkey.keys != None:  # we had a response
        cicloricarica.addData('Exitkey.rt', Exitkey.rt)
    if(key_select.keys == 'space'):
            cicloricarica.finished=1
    # the Routine "charcedordischarced" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "motorEnd"-------
    continueRoutine = True
    routineTimer.add(0.100000)
    # update component parameters for each repeat
    # keep track of which components have finished
    motorEndComponents = [polygon_2]
    for thisComponent in motorEndComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    motorEndClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "motorEnd"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = motorEndClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=motorEndClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *polygon_2* updates
        if polygon_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            polygon_2.frameNStart = frameN  # exact frame index
            polygon_2.tStart = t  # local t and not account for scr refresh
            polygon_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(polygon_2, 'tStartRefresh')  # time at next scr refresh
            polygon_2.setAutoDraw(True)
        if polygon_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > polygon_2.tStartRefresh + 0.1-frameTolerance:
                # keep track of stop time/frame for later
                polygon_2.tStop = t  # not accounting for scr refresh
                polygon_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(polygon_2, 'tStopRefresh')  # time at next scr refresh
                polygon_2.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in motorEndComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "motorEnd"-------
    for thisComponent in motorEndComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    #Invio segnale di blocco ad arduino
    a="S";
    port.write(a.encode('utf-8'))
    port.flush()   
    cicloricarica.addData('polygon_2.started', polygon_2.tStartRefresh)
    cicloricarica.addData('polygon_2.stopped', polygon_2.tStopRefresh)
# completed 10.0 repeats of 'cicloricarica'


# ------Prepare to start Routine "Start"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
StartComponents = []
for thisComponent in StartComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
StartClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Start"-------
while continueRoutine:
    # get current time
    t = StartClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=StartClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in StartComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Start"-------
for thisComponent in StartComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "Start" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Instruct"-------
continueRoutine = True
# update component parameters for each repeat
ready.keys = []
ready.rt = []
_ready_allKeys = []
# keep track of which components have finished
InstructComponents = [instrText, ready]
for thisComponent in InstructComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
InstructClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Instruct"-------
while continueRoutine:
    # get current time
    t = InstructClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=InstructClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instrText* updates
    if instrText.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        instrText.frameNStart = frameN  # exact frame index
        instrText.tStart = t  # local t and not account for scr refresh
        instrText.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instrText, 'tStartRefresh')  # time at next scr refresh
        instrText.setAutoDraw(True)
    
    # *ready* updates
    waitOnFlip = False
    if ready.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        ready.frameNStart = frameN  # exact frame index
        ready.tStart = t  # local t and not account for scr refresh
        ready.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(ready, 'tStartRefresh')  # time at next scr refresh
        ready.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(ready.clock.reset)  # t=0 on next screen flip
    if ready.status == STARTED and not waitOnFlip:
        theseKeys = ready.getKeys(keyList=None, waitRelease=False)
        _ready_allKeys.extend(theseKeys)
        if len(_ready_allKeys):
            ready.keys = _ready_allKeys[-1].name  # just the last key pressed
            ready.rt = _ready_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in InstructComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Instruct"-------
for thisComponent in InstructComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "Instruct" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=expInfo['num_trial'], method='fullRandom', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('trialTypes.xlsx', selection='0,1,2,3'),
    seed=None, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial:
        exec('{} = thisTrial[paramName]'.format(paramName))

for thisTrial in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "countdown"-------
    continueRoutine = True
    # update component parameters for each repeat
    # keep track of which components have finished
    countdownComponents = [time3]
    for thisComponent in countdownComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    countdownClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "countdown"-------
    while continueRoutine:
        # get current time
        t = countdownClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=countdownClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *time3* updates
        if time3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            time3.frameNStart = frameN  # exact frame index
            time3.tStart = t  # local t and not account for scr refresh
            time3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(time3, 'tStartRefresh')  # time at next scr refresh
            time3.setAutoDraw(True)
        if time3.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > time3.tStartRefresh + random()-frameTolerance:
                # keep track of stop time/frame for later
                time3.tStop = t  # not accounting for scr refresh
                time3.frameNStop = frameN  # exact frame index
                win.timeOnFlip(time3, 'tStopRefresh')  # time at next scr refresh
                time3.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in countdownComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "countdown"-------
    for thisComponent in countdownComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "countdown" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    repet_tastant = data.TrialHandler(nReps=expInfo['num_stim'], method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='repet_tastant')
    thisExp.addLoop(repet_tastant)  # add the loop to the experiment
    thisRepet_tastant = repet_tastant.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisRepet_tastant.rgb)
    if thisRepet_tastant != None:
        for paramName in thisRepet_tastant:
            exec('{} = thisRepet_tastant[paramName]'.format(paramName))
    
    for thisRepet_tastant in repet_tastant:
        currentLoop = repet_tastant
        # abbreviate parameter names if possible (e.g. rgb = thisRepet_tastant.rgb)
        if thisRepet_tastant != None:
            for paramName in thisRepet_tastant:
                exec('{} = thisRepet_tastant[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "trial"-------
        continueRoutine = True
        routineTimer.add(2.000000)
        # update component parameters for each repeat
        if letterColor=='red':
            #il motore 2 è associato allo stimolo dolce
            a="2";
            #port.write(struct.pack('>f',float(i)))
            port.write(a.encode('utf-8'))
            port.flush()
        else:
            #il motore 1 è associato allo stimolo salato
            a="1";
            #port.write(struct.pack('>f',float(i)))
            port.write(a.encode('utf-8'))
            port.flush()
        print("py response motor: "+a)
        print(letterColor)
        image.setImage(immage)
        # keep track of which components have finished
        trialComponents = [image]
        for thisComponent in trialComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        trialClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "trial"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = trialClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=trialClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
                
            
            
            # *image* updates
            if image.status == NOT_STARTED and tThisFlip >= 1.0-frameTolerance:
                # keep track of start time/frame for later
                image.frameNStart = frameN  # exact frame index
                image.tStart = t  # local t and not account for scr refresh
                image.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image, 'tStartRefresh')  # time at next scr refresh
                image.setAutoDraw(True)
            if image.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > image.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    image.tStop = t  # not accounting for scr refresh
                    image.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(image, 'tStopRefresh')  # time at next scr refresh
                    image.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in trialComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "trial"-------
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        repet_tastant.addData('image.started', image.tStartRefresh)
        repet_tastant.addData('image.stopped', image.tStopRefresh)
        
        # ------Prepare to start Routine "jitter"-------
        continueRoutine = True
        # update component parameters for each repeat
        # keep track of which components have finished
        jitterComponents = [fix_rand]
        for thisComponent in jitterComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        jitterClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "jitter"-------
        while continueRoutine:
            # get current time
            t = jitterClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=jitterClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fix_rand* updates
            if fix_rand.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fix_rand.frameNStart = frameN  # exact frame index
                fix_rand.tStart = t  # local t and not account for scr refresh
                fix_rand.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fix_rand, 'tStartRefresh')  # time at next scr refresh
                fix_rand.setAutoDraw(True)
            if fix_rand.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fix_rand.tStartRefresh + random()+1-frameTolerance:
                    # keep track of stop time/frame for later
                    fix_rand.tStop = t  # not accounting for scr refresh
                    fix_rand.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(fix_rand, 'tStopRefresh')  # time at next scr refresh
                    fix_rand.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in jitterComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "jitter"-------
        for thisComponent in jitterComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "jitter" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed expInfo['num_stim'] repeats of 'repet_tastant'
    
    # get names of stimulus parameters
    if repet_tastant.trialList in ([], [None], None):
        params = []
    else:
        params = repet_tastant.trialList[0].keys()
    # save data for this loop
    repet_tastant.saveAsExcel(filename + '.xlsx', sheetName='repet_tastant',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    repet_tastant.saveAsText(filename + 'repet_tastant.csv', delim=',',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # ------Prepare to start Routine "risposta"-------
    continueRoutine = True
    # update component parameters for each repeat
    Risposta.keys = []
    Risposta.rt = []
    _Risposta_allKeys = []
    # keep track of which components have finished
    rispostaComponents = [Risposta, LeftorRight]
    for thisComponent in rispostaComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    rispostaClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "risposta"-------
    while continueRoutine:
        # get current time
        t = rispostaClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=rispostaClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Risposta* updates
        waitOnFlip = False
        if Risposta.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Risposta.frameNStart = frameN  # exact frame index
            Risposta.tStart = t  # local t and not account for scr refresh
            Risposta.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Risposta, 'tStartRefresh')  # time at next scr refresh
            Risposta.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(Risposta.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(Risposta.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if Risposta.status == STARTED and not waitOnFlip:
            theseKeys = Risposta.getKeys(keyList=['left','right'], waitRelease=False)
            _Risposta_allKeys.extend(theseKeys)
            if len(_Risposta_allKeys):
                Risposta.keys = _Risposta_allKeys[-1].name  # just the last key pressed
                Risposta.rt = _Risposta_allKeys[-1].rt
                # was this correct?
                if (Risposta.keys == str(corrAns)) or (Risposta.keys == corrAns):
                    Risposta.corr = 1
                else:
                    Risposta.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # *LeftorRight* updates
        if LeftorRight.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            LeftorRight.frameNStart = frameN  # exact frame index
            LeftorRight.tStart = t  # local t and not account for scr refresh
            LeftorRight.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(LeftorRight, 'tStartRefresh')  # time at next scr refresh
            LeftorRight.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in rispostaComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "risposta"-------
    for thisComponent in rispostaComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if Risposta.keys in ['', [], None]:  # No response was made
        Risposta.keys = None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           Risposta.corr = 1;  # correct non-response
        else:
           Risposta.corr = 0;  # failed to respond (incorrectly)
    # store data for trials (TrialHandler)
    trials.addData('Risposta.keys',Risposta.keys)
    trials.addData('Risposta.corr', Risposta.corr)
    if Risposta.keys != None:  # we had a response
        trials.addData('Risposta.rt', Risposta.rt)
    trials.addData('Risposta.started', Risposta.tStartRefresh)
    trials.addData('Risposta.stopped', Risposta.tStopRefresh)
    # the Routine "risposta" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    repet_neutral = data.TrialHandler(nReps=expInfo['cleaning'], method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='repet_neutral')
    thisExp.addLoop(repet_neutral)  # add the loop to the experiment
    thisRepet_neutral = repet_neutral.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisRepet_neutral.rgb)
    if thisRepet_neutral != None:
        for paramName in thisRepet_neutral:
            exec('{} = thisRepet_neutral[paramName]'.format(paramName))
    
    for thisRepet_neutral in repet_neutral:
        currentLoop = repet_neutral
        # abbreviate parameter names if possible (e.g. rgb = thisRepet_neutral.rgb)
        if thisRepet_neutral != None:
            for paramName in thisRepet_neutral:
                exec('{} = thisRepet_neutral[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "neutral"-------
        continueRoutine = True
        routineTimer.add(2.500000)
        # update component parameters for each repeat
        stim_neutral_word.setColor([1.0000, 1.0000, 1.0000], colorSpace='rgb')
        stim_neutral_word.setText('Cleaning')
        a="0";
        port.write(a.encode('utf-8'))
        port.flush()
        print("py response motor: "+a)
        # keep track of which components have finished
        neutralComponents = [stim_neutral_word]
        for thisComponent in neutralComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        neutralClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "neutral"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = neutralClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=neutralClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *stim_neutral_word* updates
            if stim_neutral_word.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                stim_neutral_word.frameNStart = frameN  # exact frame index
                stim_neutral_word.tStart = t  # local t and not account for scr refresh
                stim_neutral_word.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stim_neutral_word, 'tStartRefresh')  # time at next scr refresh
                stim_neutral_word.setAutoDraw(True)
            if stim_neutral_word.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > stim_neutral_word.tStartRefresh + 2-frameTolerance:
                    # keep track of stop time/frame for later
                    stim_neutral_word.tStop = t  # not accounting for scr refresh
                    stim_neutral_word.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(stim_neutral_word, 'tStopRefresh')  # time at next scr refresh
                    stim_neutral_word.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in neutralComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "neutral"-------
        for thisComponent in neutralComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
    # completed expInfo['cleaning'] repeats of 'repet_neutral'
    
# completed expInfo['num_trial'] repeats of 'trials'


# ------Prepare to start Routine "thanks"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
# keep track of which components have finished
thanksComponents = [thanksText]
for thisComponent in thanksComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
thanksClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "thanks"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = thanksClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=thanksClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *thanksText* updates
    if thanksText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        thanksText.frameNStart = frameN  # exact frame index
        thanksText.tStart = t  # local t and not account for scr refresh
        thanksText.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(thanksText, 'tStartRefresh')  # time at next scr refresh
        thanksText.setAutoDraw(True)
    if thanksText.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > thanksText.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            thanksText.tStop = t  # not accounting for scr refresh
            thanksText.frameNStop = frameN  # exact frame index
            win.timeOnFlip(thanksText, 'tStopRefresh')  # time at next scr refresh
            thanksText.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in thanksComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "thanks"-------
for thisComponent in thanksComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='semicolon')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
